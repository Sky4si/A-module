MODDIR=${0%/*}

while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 2
done
sleep 10
mkdir -p /data/adb/tricky_store
echo "com.google.android.gms" > /data/adb/tricky_store/target.txt
pm list packages -3 | sed 's/package://g' >> /data/adb/tricky_store/target.txt
cat /data/adb/tricky_store/target.txt
sleep 1
#TG电报频道@Whitelist520
function auto_game_mode_node () {
	while true ; do
	mkdir -p /data/adb/tricky_store
	echo "com.google.android.gms" > /data/adb/tricky_store/target.txt
	pm list packages -3 | sed 's/package://g' >> /data/adb/tricky_store/target.txt
rm -rf /data/adb/modules/Tricky_store-bm/module.prop
echo "id=Tricky_store-bm" >/data/adb/modules/Tricky_store-bm/module.prop
echo "name=Tricky_store自动更新包名列表" >>/data/adb/modules/Tricky_store-bm/module.prop
echo -n "version=TG电报频道:@Whitelist520" >>/data/adb/modules/Tricky_store-bm/module.prop
echo ${latest_v2ray_version} >>/data/adb/modules/Tricky_store-bm/module.prop
echo "versionCode=20240828" >>/data/adb/modules/Tricky_store-bm/module.prop
echo "author=阿灵" >>/data/adb/modules/Tricky_store-bm/module.prop
echo "description=开机自启自动更新包名列表，每12小时自动更新包名列表" >>/data/adb/modules/Tricky_store-bm/module.prop

	sleep 43200
	done
}
auto_game_mode_node &